-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Računalo: localhost
-- Vrijeme generiranja: Lip 09, 2014 u 01:34 PM
-- Verzija poslužitelja: 5.5.24-log
-- PHP verzija: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza podataka: `sibaza`
--
CREATE DATABASE `sibaza` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `sibaza`;

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `klijent`
--

CREATE TABLE IF NOT EXISTS `klijent` (
  `klijentId` bigint(20) NOT NULL AUTO_INCREMENT,
  `osobaId` bigint(20) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`klijentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `kredit`
--

CREATE TABLE IF NOT EXISTS `kredit` (
  `kreditId` bigint(20) NOT NULL AUTO_INCREMENT,
  `datumUpisa` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `klijentId` bigint(20) DEFAULT NULL,
  `uposlenikId` bigint(20) DEFAULT NULL,
  `tipKreditaId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`kreditId`),
  KEY `FK_fxir3rru1hdfrxuldbjdo3gb0` (`klijentId`),
  KEY `FK_q6khsbox867th74t0p911sek6` (`uposlenikId`),
  KEY `FK_fry44jjkeffg0b5hq8pcxq2y9` (`tipKreditaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `osoba`
--

CREATE TABLE IF NOT EXISTS `osoba` (
  `osobaId` bigint(20) NOT NULL AUTO_INCREMENT,
  `adresa` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `aktivan` bit(1) DEFAULT NULL,
  `datumRodjenja` date DEFAULT NULL,
  `datumUnosa` date DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `imePrezime` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `jmbg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `obrazovanje` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `telefon` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`osobaId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Izbacivanje podataka za tablicu `osoba`
--

INSERT INTO `osoba` (`osobaId`, `adresa`, `aktivan`, `datumRodjenja`, `datumUnosa`, `email`, `imePrezime`, `jmbg`, `obrazovanje`, `telefon`) VALUES
(1, 'Vrbovska 178', b'1', '1992-03-31', '2014-06-09', 'artmob49@gmail.com', 'Arnela Tumbul', '3103992175103', 'BoEE', '061-916-987');

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `tipkredita`
--

CREATE TABLE IF NOT EXISTS `tipkredita` (
  `tipKreditaId` bigint(20) NOT NULL AUTO_INCREMENT,
  `garancija` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `gracePeriod` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `instrumentiObezbjedjenja` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `iznos` double DEFAULT NULL,
  `kamatnaStopa` double DEFAULT NULL,
  `namjena` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `naziv` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `rok` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `troskoviObrade` double DEFAULT NULL,
  PRIMARY KEY (`tipKreditaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `transakcija`
--

CREATE TABLE IF NOT EXISTS `transakcija` (
  `transakcijaId` bigint(20) NOT NULL AUTO_INCREMENT,
  `datumUplate` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `iznosUplate` double DEFAULT NULL,
  `nacinUplate` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `redniBrUplate` int(11) NOT NULL,
  `klijentId` bigint(20) DEFAULT NULL,
  `kreditId` bigint(20) DEFAULT NULL,
  `uposlenikId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`transakcijaId`),
  KEY `FK_ahjdde5mwokyjtn14nr96yucv` (`klijentId`),
  KEY `FK_1e3y8rves2uo1eequtbo6fn4v` (`kreditId`),
  KEY `FK_3wt4avuuflcye5v648dj97u3u` (`uposlenikId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `uposlenik`
--

CREATE TABLE IF NOT EXISTS `uposlenik` (
  `uposlenikId` bigint(20) NOT NULL AUTO_INCREMENT,
  `mjestoRodjenja` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `osobaId` bigint(20) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `plata` double DEFAULT NULL,
  `privilegije` bit(1) DEFAULT NULL,
  `ukupanBrKredita` int(11) NOT NULL,
  `ukupanBrTransakcija` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`uposlenikId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Izbacivanje podataka za tablicu `uposlenik`
--

INSERT INTO `uposlenik` (`uposlenikId`, `mjestoRodjenja`, `osobaId`, `password`, `plata`, `privilegije`, `ukupanBrKredita`, `ukupanBrTransakcija`, `username`) VALUES
(1, 'Sarajevo', 1, 'pass', 2200.5, b'1', 200, 350, '3103992175103');

--
-- Ograničenja za izbačene tablice
--

--
-- Ograničenja za tablicu `kredit`
--
ALTER TABLE `kredit`
  ADD CONSTRAINT `FK_fry44jjkeffg0b5hq8pcxq2y9` FOREIGN KEY (`tipKreditaId`) REFERENCES `tipkredita` (`tipKreditaId`),
  ADD CONSTRAINT `FK_fxir3rru1hdfrxuldbjdo3gb0` FOREIGN KEY (`klijentId`) REFERENCES `klijent` (`klijentId`),
  ADD CONSTRAINT `FK_q6khsbox867th74t0p911sek6` FOREIGN KEY (`uposlenikId`) REFERENCES `uposlenik` (`uposlenikId`);

--
-- Ograničenja za tablicu `transakcija`
--
ALTER TABLE `transakcija`
  ADD CONSTRAINT `FK_3wt4avuuflcye5v648dj97u3u` FOREIGN KEY (`uposlenikId`) REFERENCES `uposlenik` (`uposlenikId`),
  ADD CONSTRAINT `FK_1e3y8rves2uo1eequtbo6fn4v` FOREIGN KEY (`kreditId`) REFERENCES `kredit` (`kreditId`),
  ADD CONSTRAINT `FK_ahjdde5mwokyjtn14nr96yucv` FOREIGN KEY (`klijentId`) REFERENCES `klijent` (`klijentId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
